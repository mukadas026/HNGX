import React from "react"
import Header from "../components/Header"
import FeaturedMovies from "../components/FeaturedMovies"
import Layout from "../layout/Layout"

const Home = () => {
	return (
		<Layout>
			<Header />
			<FeaturedMovies />
		</Layout>
	)
}

export default Home
