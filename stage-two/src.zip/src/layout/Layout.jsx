import React from "react"
import Navbar from "../components/Navbar"
import Footer from "../components/Footer"

const Layout = ({ children }) => {
	return (
		<div className='w-screen max-w-[1980px] relative mx-auto'>
			<Navbar />
			<main className='w-full'>{children}</main>
			<Footer />
		</div>
	)
}

export default Layout
