import React from 'react'

const SearchModal = () => {
  return (
    <div>SearchModal</div>
  )
}

export default SearchModal